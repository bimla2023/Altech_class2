package class2_assingments;

public class Ointment extends Medicine {

	public void displayLabel() {
		
		System.out.println("Inside Ointment");
	}
}
