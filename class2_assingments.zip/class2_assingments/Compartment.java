package class2_assingments;

abstract public class Compartment {
	
	//abstract method
	abstract void notice();

}
