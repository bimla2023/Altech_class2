package class2_assingments;

abstract public class Medicine {

	public void displayLabel(String Name, String address) {
		
		
		System.out.println("Name of the company : " +Name +"  Address of the company : " +address);
	}

}
