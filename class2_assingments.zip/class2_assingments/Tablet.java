package class2_assingments;

public class Tablet extends Medicine {
	
	public void displayLabel() {
	
		System.out.println("Tablet should store in a cool dry place");
		
	}

}
