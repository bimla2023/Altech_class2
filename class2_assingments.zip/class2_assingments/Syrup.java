package class2_assingments;

public class Syrup extends Medicine{
	
	 public void displayLabel() {
		
		 System.out.println("Inside Syrup");
	}

}
