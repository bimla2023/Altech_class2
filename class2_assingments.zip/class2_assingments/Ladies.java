package class2_assingments;

public class Ladies extends Compartment{
	
	@Override
	void notice() {
		System.out.println("Ladies");
		
	}

}
