package class2_assingments;

abstract public class Instrument {
	
	//abstract method 
	abstract public void play();

}
