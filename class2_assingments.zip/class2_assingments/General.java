package class2_assingments;

public class General extends Compartment {
	
	
		@Override
		void notice() {
			System.out.println("General");
			
		}

	
	

}
