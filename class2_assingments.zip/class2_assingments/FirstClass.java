package class2_assingments;

public class FirstClass extends Compartment {

	@Override
	void notice() {
		System.out.println("FirstClass");
		
	}

}
